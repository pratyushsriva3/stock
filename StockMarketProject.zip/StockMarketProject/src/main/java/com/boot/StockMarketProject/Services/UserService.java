package com.boot.StockMarketProject.Services;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.boot.StockMarketProject.Models.User;

public interface UserService extends JpaRepository<User, Integer> {

	
    
	
	

	@Query("Select u From User u where u.Email = :email")
	User findByEmail(String email);
}
