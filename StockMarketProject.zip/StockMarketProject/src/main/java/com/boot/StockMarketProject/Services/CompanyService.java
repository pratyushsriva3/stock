package com.boot.StockMarketProject.Services;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boot.StockMarketProject.Models.Company;

public interface CompanyService extends JpaRepository<Company, Integer> {

}
