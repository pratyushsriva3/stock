package com.boot.StockMarketProject.Services;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boot.StockMarketProject.Models.StockExchange;

public interface StockExchangeService extends JpaRepository<StockExchange, Integer> {

}
