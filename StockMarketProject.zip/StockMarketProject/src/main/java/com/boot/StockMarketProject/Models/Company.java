package com.boot.StockMarketProject.Models;

import java.math.BigInteger;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.boot.StockMarketProject.Models.Sector;
import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "Company")
public class Company {

    @Id
	@Column(name = "Id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int CompanyCode;
	

	@NotNull(message = "Enter Required Value")
	@Column(name = "CompanyName")
	private String CompanyName;
	
	
	@NotNull(message = "Enter Required Value")
	@Column(name = "TurnOver")
	private BigInteger TurnOver;
	

	@NotNull(message = "Enter Required Value")
	@Column(name = "CEO")
	private String CEO;
	

	public Company() {
		super();
	}

    @NotNull(message = "Enter Required Value")
	@Column(name = "BoardOfDirectors")
	private String BoardOfDirectors;
	

	@JoinColumn(name = "Sectorid")
	@NotNull(message = "Enter Required Value")
	@ManyToOne(fetch = FetchType.EAGER , cascade=CascadeType.ALL)
	@JsonBackReference
	private Sector Sector;
	

	@NotNull(message = "Enter Required Value")
	@Column(name = "BriefWriteup")private String Brief;
	

	@NotNull(message = "Enter Required Value")
	@Column(name = "StockCode")
	private String StockCode;

	public Company(@NotNull(message = "Enter Required Value") String CompanyName,
			@NotNull(message = "Enter Required Value") BigInteger TurnOver,
			@NotNull(message = "Enter Required Value") String CEO,
			@NotNull(message = "Enter Required Value") String BoardOfDirectors,
			@NotNull(message = "Enter Required Value") Sector Sector,
			@NotNull(message = "Enter Required Value") String Brief,
			@NotNull(message = "Enter Required Value") String StockCode) {
		super();
		this.CompanyName = CompanyName;
		this.TurnOver = TurnOver;
		this.CEO = CEO;
		this.BoardOfDirectors = BoardOfDirectors;
		this.Sector = Sector;
		this.Brief = Brief;
		this.StockCode = StockCode;
	}

	public int getCompanyCode() {
		return CompanyCode;
	}

	public void setCompanyCode(int companyCode) {
		CompanyCode = companyCode;
	}

	public String getCompanyName() {
		return CompanyName;
	}

	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}

	public BigInteger getTurnOver() {
		return TurnOver;
	}

	public void setTurnOver(BigInteger turnOver) {
		TurnOver = turnOver;
	}

	public String getCEO() {
		return CEO;
	}

	public void setCEO(String cEO) {
		CEO = cEO;
	}

	public String getBoardOfDirectors() {
		return BoardOfDirectors;
	}

	public void setBoardOfDirectors(String boardOfDirectors) {
		BoardOfDirectors = boardOfDirectors;
	}

	public Sector getSector() {
		return Sector;
	}

	public void setSector(Sector sector) {
		Sector = sector;
	}

	public String getBrief() {
		return Brief;
	}

	public void setBrief(String brief) {
		Brief = brief;
	}

	public String getStockCode() {
		return StockCode;
	}

	public void setStockCode(String stockCode) {
		StockCode = stockCode;
	}
	

}
