package com.boot.StockMarket.services;

import java.sql.SQLException;
import java.util.List;

import com.boot.StockMarket.model.Company;

public interface CompanyServices {
	
	public Company insertCompany(Company comp) throws SQLException;
	public Company updateCompany(Company comp);
	public List<Company> getCompanyList() throws SQLException;

}
