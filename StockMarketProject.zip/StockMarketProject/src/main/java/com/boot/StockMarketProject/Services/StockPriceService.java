package com.boot.StockMarketProject.Services;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.boot.StockMarketProject.Models.StockPrice;

public interface StockPriceService extends JpaRepository<StockPrice, Integer>{

	@Query(value ="Select sum(CurrentPrice) from StockPrice where CompanyId in (select Id from Company where sector_id= :id)",nativeQuery=true)
    float FindStockPrice(@Param("id") int id);

	@Query(value ="Select sum(current_price) from stock_price where company_id = :id",nativeQuery=true)
	float FindCompanyPrice(int id);
}
