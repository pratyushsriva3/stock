package com.boot.StockMarket.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name="company")
@SequenceGenerator(name= "seq", initialValue = 2001, allocationSize = 1)
public class Company {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	@Column(name = "company_code")
	private int companyCode;
	
	@Column(name = "company_name")
	private String companyName;

	@Column(name = "ceo")
	private String ceo;
	
	@Column(name = "board_of_directors")
	private String boardofDirectors;
	
	@Column(name = "brief")
	private String brief;
	
	@Column(name = "stock_code")
	private int stock_code;
	
	@Column(name = "turnover")
	private double turnover;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "sector_id")
	@Column(name = "sector")
	private List<Sector> sector;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "stock_exchange_id")
	@Column(name = "stock_exchanges")
	private List<StockExchange> stock_exchanges;

	public int getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(int companyCode) {
		this.companyCode = companyCode;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCeo() {
		return ceo;
	}

	public void setCeo(String ceo) {
		this.ceo = ceo;
	}

	public String getBoardofDirectors() {
		return boardofDirectors;
	}

	public void setBoardofDirectors(String boardofDirectors) {
		this.boardofDirectors = boardofDirectors;
	}

	public String getBrief() {
		return brief;
	}

	public void setBrief(String brief) {
		this.brief = brief;
	}

	public int getStock_code() {
		return stock_code;
	}

	public void setStock_code(int stock_code) {
		this.stock_code = stock_code;
	}

	public double getTurnover() {
		return turnover;
	}

	public void setTurnover(double turnover) {
		this.turnover = turnover;
	}

	public List<Sector> getSector() {
		return sector;
	}

	public void setSector(List<Sector> sector) {
		this.sector = sector;
	}

	public List<StockExchange> getStock_exchanges() {
		return stock_exchanges;
	}

	public void setStock_exchanges(List<StockExchange> stock_exchanges) {
		this.stock_exchanges = stock_exchanges;
	}
}
