package com.boot.StockMarketProject.Models;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "User")
public class User {

	
	@Id
	@Column(name = "Id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int Id;
	
	public User() {
		// TODO Auto-generated constructor stub
	}


	@Column(name = "Username")
	@NotNull(message = "Enter Required Value")
	private String Username;
	
 
	@Column(name = "Password")
	@NotNull(message = "Enter Required Value")
	private String Password;
	
	
	@Column(name = "Usertype")
    private String UserType;
	
    
	@Column(name = "Email")
	@NotNull(message = "Enter Required Value")
	private String Email;
	

	@Column(name = "MobileNumber")
	@NotNull(message = "Enter Required Value")
	private int MobileNumber;
	

	@Column(name = "Confirmed")
    private String Confirmed;
	
	public User( String Username, String Password, String UserType, String Email, int MobileNumber,
			String Confirmed) {
		super();
		this.Username = Username;
		this.Password = Password;
		this.UserType = UserType;
		this.Email = Email;
		this.MobileNumber = MobileNumber;
		this.Confirmed = Confirmed;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getUserType() {
		return UserType;
	}

	public void setUserType(String userType) {
		UserType = userType;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public int getMobileNumber() {
		return MobileNumber;
	}

	public void setMobileNumber(int mobileNumber) {
		MobileNumber = mobileNumber;
	}

	public String getConfirmed() {
		return Confirmed;
	}

	public void setConfirmed(String confirmed) {
		Confirmed = confirmed;
	}

}
