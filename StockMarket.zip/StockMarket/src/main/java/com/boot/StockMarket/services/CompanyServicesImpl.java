package com.boot.StockMarket.services;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.StockMarket.dao.CompanyRepo;
import com.boot.StockMarket.model.Company;

@Service
public class CompanyServicesImpl implements CompanyServices{
	
	@Autowired
	public CompanyRepo CompRepo;

	@Override
	public Company insertCompany(Company comp) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Company updateCompany(Company comp) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Company> getCompanyList() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	

}
