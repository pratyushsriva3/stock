package com.boot.StockMarketProject.Models;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="StockPrice")
public class StockPrice {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name="StockPriceId")
private int StockPriceId;


@Column(name="CompanyId")
private int CompanyCode;

@Column(name="StockExchangeId")
private int StockExchangeId;

@Column(name="CurrentPrice")
private float CurrentPrice;

@Column(name="Date")
private Date Date;

@Column(name="Time")
private Date Time;


public StockPrice() {
	super();
}
public StockPrice(int CompanyCode, int StockExchangeId, float CurrentPrice, Date Date, Date Time) {
	super();
	this.CompanyCode = CompanyCode;
	this.StockExchangeId = StockExchangeId;
	this.CurrentPrice = CurrentPrice;
	this.Date = Date;
	this.Time = Time;
}
public int getStockPriceId() {
	return StockPriceId;
}
public void setStockPriceId(int stockPriceId) {
	StockPriceId = stockPriceId;
}
public int getCompanyCode() {
	return CompanyCode;
}
public void setCompanyCode(int companyCode) {
	CompanyCode = companyCode;
}
public int getStockExchangeId() {
	return StockExchangeId;
}
public void setStockExchangeId(int stockExchangeId) {
	StockExchangeId = stockExchangeId;
}
public float getCurrentPrice() {
	return CurrentPrice;
}
public void setCurrentPrice(float currentPrice) {
	CurrentPrice = currentPrice;
}
public Date getDate() {
	return Date;
}
public void setDate(Date date) {
	Date = date;
}
public Date getTime() {
	return Time;
}
public void setTime(Date time) {
	Time = time;
}

}
