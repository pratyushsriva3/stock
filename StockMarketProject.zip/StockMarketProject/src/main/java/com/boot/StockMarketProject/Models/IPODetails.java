package com.boot.StockMarketProject.Models;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Entity
@Table(name="Ipo")
public class IPODetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ipo_id")
	private int IpoId;


	@Column(name="CompanyName")
	private String CompanyName;


	@Column(name="StockExchangeId")
	private int StockExchangeId;


	@Column(name="PricePerShare")
	private float PricePerShare;


	@Column(name="TotalNumberOfShares")
	private int TotalNumberOfShares;


	@Column(name="OpenDateTime")
	private Date OpenDateTime;


	@Column(name="IpoRemarks")
	private String IpoRemarks;


	public int getIpoId() {
		return IpoId;
	}


	public void setIpoId(int ipoId) {
		IpoId = ipoId;
	}


	public String getCompanyName() {
		return CompanyName;
	}


	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}


	public int getStockExchangeId() {
		return StockExchangeId;
	}


	public void setStockExchangeId(int stockExchangeId) {
		StockExchangeId = stockExchangeId;
	}


	public float getPricePerShare() {
		return PricePerShare;
	}


	public void setPricePerShare(float pricePerShare) {
		PricePerShare = pricePerShare;
	}


	public int getTotalNumberOfShares() {
		return TotalNumberOfShares;
	}


	public void setTotalNumberOfShares(int totalNumberOfShares) {
		TotalNumberOfShares = totalNumberOfShares;
	}


	public Date getOpenDateTime() {
		return OpenDateTime;
	}


	public void setOpenDateTime(Date openDateTime) {
		OpenDateTime = openDateTime;
	}


	public String getIpoRemarks() {
		return IpoRemarks;
	}


	public void setIpoRemarks(String ipoRemarks) {
		IpoRemarks = ipoRemarks;
	}


	
}
