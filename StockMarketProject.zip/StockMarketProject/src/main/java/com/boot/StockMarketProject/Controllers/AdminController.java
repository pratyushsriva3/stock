package com.boot.StockMarketProject.Controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.StockMarketProject.Services.CompanyService;
import com.boot.StockMarketProject.Services.IPOService;
import com.boot.StockMarketProject.Services.SectorService;
import com.boot.StockMarketProject.Services.StockPriceService;
import com.boot.StockMarketProject.Services.StockExchangeService;
import com.boot.StockMarketProject.Services.UserService;
import com.boot.StockMarketProject.Models.StockExchange;
import com.boot.StockMarketProject.Models.StockPrice;
import com.boot.StockMarketProject.Models.User;
import com.boot.StockMarketProject.Models.Company;
import com.boot.StockMarketProject.Models.IPODetails;
import com.boot.StockMarketProject.Models.Sector;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/StockMarket")
public class AdminController {
	
	@Autowired
	CompanyService CompService;
	
	@Autowired
	IPOService IPOService;
	
	@Autowired
	StockPriceService StockPriceService;
	
	@Autowired
	SectorService SectorService;
	
	@Autowired
	StockExchangeService StockExchangeService;
	
	@Autowired
	UserService UserService;
	
	@PostMapping(value = "/Company/Create")
	public Company addCompany(@RequestBody Company company) {

		Company compobj1 = CompService.save(company);
		return compobj1;
	}

	@PostMapping(value = "/StockExchange/Create")
	public StockExchange addExchange(@RequestBody StockExchange stockexchange) {

		StockExchange stockexchangeobj1 = StockExchangeService.save(stockexchange);
		return stockexchangeobj1;
	}
	
	@PostMapping(value = "/IPO/Create")
	public IPODetails addIPO(@RequestBody IPODetails ipodetails) {

		IPODetails ipodetailsobj1 = IPOService.save(ipodetails);
		return ipodetailsobj1;
	}
	
	@GetMapping(value= "/User/GetUser")
	public List<User> getAllUsers() {
		
		List<User> userinfo = new ArrayList<>();
		UserService.findAll().forEach(userinfo::add);
		return userinfo;
	}
	
	@GetMapping(value="/Company/GetCompany")
	public List<Company> getAllCompanies() {
		List<Company> companies = new ArrayList<>();
		CompService.findAll().forEach(companies::add);
		return companies;
	}
	
	@GetMapping(value="/IPODetails/GetIPOlist")
	public List<IPODetails> getAllIPO() {
		List<IPODetails> IPOinfo = new ArrayList<>();
		IPOService.findAll().forEach(IPOinfo::add);
		return IPOinfo;
	}
	
	@GetMapping(value="/StockExchange/GetStockExchange")
	public List<StockExchange> getStockExchanges() {
		List<StockExchange> stockexchanges = new ArrayList<>();
		StockExchangeService.findAll().forEach(stockexchanges::add);
		return stockexchanges;
	}
	
	@GetMapping(value="/StockPrice/GetStockPrice")
	public List<StockPrice> getStockPrice() {
		List<StockPrice> stockprice = new ArrayList<>();
		StockPriceService.findAll().forEach(stockprice::add);
		return stockprice;
	}
	
	@GetMapping(value="/Sector/GetCompany/{id}")
	public List<Sector> findCompanyBySector(@PathVariable int id) {
		List<Sector> companies = SectorService.FindCompaniesBySector(id);
		return companies;
	}
	
	@GetMapping(value="/StockPrice/GetStockPrice/{id}")
	public float findStockPrice(@PathVariable int id) {
		float stockprice = StockPriceService.FindStockPrice(id);
		return stockprice;
	}
}
