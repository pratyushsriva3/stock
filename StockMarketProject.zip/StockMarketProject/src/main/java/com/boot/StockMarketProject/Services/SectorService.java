package com.boot.StockMarketProject.Services;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.boot.StockMarketProject.Models.Sector;

public interface SectorService extends JpaRepository<Sector, Integer>{
	
	@Query("Select c From Sector c where c.id = :id")
	List<Sector> FindCompaniesBySector(@Param("id") int id);
}
