package com.boot.StockMarket.services;

import java.sql.SQLException;
import java.util.List;

import com.boot.StockMarket.model.Sector;

public interface SectorServices {

	public Sector insertSector(Sector sect) throws SQLException;
	public Sector updateSector(Sector sect);
	public List<Sector> getSectorList() throws SQLException;
}
