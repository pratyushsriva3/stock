package com.boot.StockMarket.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boot.StockMarket.model.Company;

public interface CompanyRepo extends JpaRepository<Company, Integer>{

}
