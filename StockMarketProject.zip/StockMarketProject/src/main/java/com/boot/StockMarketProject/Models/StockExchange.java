package com.boot.StockMarketProject.Models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="StockExchange")
public class StockExchange {
	@Id
	@Column(name="StockExchangeId")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int StockExchangeId;
	
	@NotNull(message="Enter required Value")
	@Pattern(regexp = "^[ A-Za-z]+$", message = "Company Name should not contain numbers")
	@Column(name="StockExchangeName")
	private String StockExchangeName;
	
	@NotNull(message="Enter required Value")
	@Column(name="Brief")
	private String Brief;
	
	@NotNull(message="Enter required Value")
	@Column(name="ContactAddress")
	private String ContactAddress;
	
	@NotNull(message="Enter required Value")
	@Column(name="Remarks")
	private String Remarks;

	public int getStockExchangeId() {
		return StockExchangeId;
	}

	public void setStockExchangeId(int stockExchangeId) {
		StockExchangeId = stockExchangeId;
	}

	public String getStockExchangeName() {
		return StockExchangeName;
	}

	public void setStockExchangeName(String stockExchangeName) {
		StockExchangeName = stockExchangeName;
	}

	public String getBrief() {
		return Brief;
	}

	public void setBrief(String brief) {
		Brief = brief;
	}

	public String getContactAddress() {
		return ContactAddress;
	}

	public void setContactAddress(String contactAddress) {
		ContactAddress = contactAddress;
	}

	public String getRemarks() {
		return Remarks;
	}

	public void setRemarks(String remarks) {
		Remarks = remarks;
	}

}
