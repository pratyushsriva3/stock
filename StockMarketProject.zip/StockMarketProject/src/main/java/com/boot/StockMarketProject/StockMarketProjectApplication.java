package com.boot.StockMarketProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockMarketProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockMarketProjectApplication.class, args);
	}

}
