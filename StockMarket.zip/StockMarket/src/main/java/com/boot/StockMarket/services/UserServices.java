package com.boot.StockMarket.services;

public interface UserServices {

}
